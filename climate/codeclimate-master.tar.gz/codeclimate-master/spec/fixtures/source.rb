class Source
  def run
    p "Run run run!"
  end
end
