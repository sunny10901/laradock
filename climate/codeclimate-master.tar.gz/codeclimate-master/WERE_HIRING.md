# Code Climate is Hiring

Thanks for checking our CLI. Since you found your way here, you may be
interested in working on open source, and building awesome tools for
developers. If so, you should check out our open jobs:

[http://jobs.codeclimate.com/](http://jobs.codeclimate.com/)

